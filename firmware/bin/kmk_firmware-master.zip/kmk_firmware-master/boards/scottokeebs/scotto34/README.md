# Scotto34

![Top Shot](https://user-images.githubusercontent.com/8194147/205760764-cce990f6-0c81-4971-ae52-ec44b2bc3c33.jpg)

Please see the [Scotto34](https://github.com/joe-scotto/scottokeebs/tree/main/Scotto34) GitHub page for details on how and what with to build this board.
