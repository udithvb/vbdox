# Boardsource 3x4

![Boardsource3x4](https://boardsource.imgix.net/30171267-d988-46cc-ba03-9f6a8ab96487.jpg?raw=true)

This macro pad / small 12 key was inspired by the plaid look

kb.py is designed to work with the nice!nano

Extensions enabled by default  
- [Layers](/docs/en/layers.md) Need more keys than switches? Use layers.

## Microcontroller support

Update this line in `kb.py` to any supported microcontroller in `kmk/quickpin/pro_micro`:

```python
from kmk.quickpin.pro_micro.boardsource_blok import pinout as pins
```
